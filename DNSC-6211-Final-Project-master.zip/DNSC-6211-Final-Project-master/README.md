# DNSC-6211-Final-Project
This repository contains the final code and report of my DNSC-6211 ( Programming for Analytics) final project. We predicted 2017 Oscars Best picture Nominations
